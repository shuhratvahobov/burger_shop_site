console.Log('Ishlayabdi')


//menu.hymlda add card bo'limiga datalarni yozish kerak

//mahsulotni id sini olish uchun js kodlaridan foydalanimiz
var updateBtns = document.getElementByIdClassName('update-cart')

for(var i = 0; i < updateBtns.length; i++){
	updateBtns[i].addEventListener('click',function(){
		var productId = this.dataset.product
		var action = this.dataset.action
		console.Log('productId:',productId,"action:",action)

		console.log('User:',user)
		if(user == 'AnonymousUser'){
				console.log('Not logging in')
		}else{
			updateUserOrder(productId,action)
		}
	})
}



//js yordamida Backendga Post yuborish uchun Token olishimiz kerak
function updateUserOrder(productId,action)	{
	console.log('User is liggin')

	var url = "/update_item/"
	fetch(url, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body:JSON.stringify({'productId': productId,'action':action})
	})
	.then((response) =>{
		return response.json()
	})
	.then((data) =>{
		console.log('data:', data)
		location.reload()
	})
}	
	