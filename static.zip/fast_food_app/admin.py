from django.contrib import admin
from .models import Mahsulotlar,Comment



admin.site.register(Mahsulotlar)
admin.site.register(Comment)
